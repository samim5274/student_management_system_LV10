
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>Exam Details-(SMS)</title>

    <!-- [Font] Family -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600&display=swap" rel="stylesheet" />
    <!-- [phosphor Icons] https://phosphoricons.com/ -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/phosphor/duotone/style.css')); ?>" />
    <!-- [Tabler Icons] https://tablericons.com -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/tabler-icons.min.css')); ?>" />
    <!-- [Feather Icons] https://feathericons.com -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/feather.css')); ?>" />
    <!-- [Font Awesome Icons] https://fontawesome.com/icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- [Material Icons] https://fonts.google.com/icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/material.css')); ?>" />
    <!-- [Template CSS Files] -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" id="main-style-link" />
</head>
<!-- [Body] Start -->

<body>
    
    <!-- [ Sidebar Menu ] start -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- [ Sidebar Menu ] end -->
    <!-- [ Header Topbar ] start -->
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- [ Header ] end -->
    <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


      <!-- [ Main Content ] start -->
      <div class="pc-container">
            <div class="pc-content">
                <!-- [ breadcrumb ] start -->
                <div class="page-header">
                    <div class="page-block">
                        <div class="page-header-title">
                            <h5 class="mb-0 font-medium">Exam Details</h5>
                        </div>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/student-list')); ?>">Student List</a></li>
                            <li class="breadcrumb-item" aria-current="page">Exam</li>
                        </ul>
                    </div>
                </div>
                <!-- [ breadcrumb ] end -->

                <!-- [ Main Content ] start -->
                <div class="grid grid-cols-1 gap-6">

                    <!-- Modal Background -->
                    <div id="examModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
                        <div class="bg-white rounded-lg shadow-lg w-full max-w-2xl p-6 relative">

                            <!-- Modal Header -->
                            <div class="flex items-center justify-between border-b pb-3 mb-4">
                                <h5 class="text-lg font-semibold text-gray-700">Add New Exam</h5>
                                <button onclick="closeModal()" class="text-gray-500 hover:text-red-600 text-2xl">&times;</button>
                            </div>

                            <!-- Modal Body (Your Form) -->
                            <form action="<?php echo e(url('/add-new-exam')); ?>" method="POST" class="space-y-6" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label for="name" class="font-medium">Exam Name</label>
                                        <select name="name" id="name" class="form-select w-full rounded-md mt-1 border-gray-300 focus:border-green-500 focus:ring-green-500">
                                            <option selected disabled>-- Select Exam --</option>
                                            <?php $__currentLoopData = $examName; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($ex->exam_name); ?>"><?php echo e($ex->exam_name); ?></option>      
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                      
                                        </select>
                                    </div>
                                    <div>
                                        <label for="class_id" class="font-medium">Class</label>
                                        <select name="class_id" id="class_id" class="form-select w-full rounded-md mt-1 border-gray-300 focus:border-green-500 focus:ring-green-500">
                                            <option disabled selected>-- Select Class --</option>
                                            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($room->id != 13): ?>
                                                <option value="<?php echo e($room->id); ?>"><?php echo e($room->name); ?> - <?php echo e($room->section); ?></option>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="subject_id" class="font-medium">Subject</label>
                                        <select name="subject_id" id="subject_id" class="form-select w-full rounded-md mt-1 border-gray-300 focus:border-green-500 focus:ring-green-500">
                                            <option disabled selected>-- Select Subject --</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="date" class="font-medium">Date</label>
                                        <input type="date" name="date" id="date" class="form-input w-full rounded-md mt-1 px-2 py-3 border-gray-300 focus:border-green-500 focus:ring-green-500">
                                    </div>
                                </div>

                                <div>
                                    <label for="max_marks" class="font-medium">Max Marks</label>
                                    <input type="number" name="max_marks" id="max_marks" min="0" max="100" value="100" placeholder="Enter Max Marks" class="form-input w-full rounded-md mt-1 px-2 py-3 border-gray-300 focus:border-green-500 focus:ring-green-500">
                                </div>

                                <!-- Submit Button -->
                                <div class="text-center">
                                    <button type="submit" class="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-6 w-full rounded-md shadow-md transition duration-300" onclick="return confirmSubmit(event)">
                                        Submit
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>


                    <div class="col-span-1">
                        <div class="card rounded-xl border">
                            <div class="flex items-center justify-between bg-gray-100 px-4 py-3 rounded-t-lg border-b">
                                <h5 class="text-lg font-semibold text-gray-700">📚 Exam List</h5>
                                
                                <button onclick="openModal()"  class="text-white bg-theme-bg-1 hover:bg-green-600 px-3 py-2 rounded-lg shadow flex items-center gap-2">
                                    <i class="fa-solid fa-folder-plus"></i>
                                    <span class="hidden sm:inline">Add Exam</span>
                                </button>
                            </div>

                            <div class="card-body">
                                <div class="overflow-x-auto">
                                    <table class="min-w-full bg-white">
                                        <thead class="bg-[#526486] text-white">
                                            <tr>
                                                <th class="py-3 px-4 uppercase font-semibold text-md">#</th>
                                                <th class="py-3 px-4 uppercase font-semibold text-md">Exam Name</th>
                                                <th class="py-3 px-4 uppercase font-semibold text-md">Date</th>
                                                <th class="py-3 px-4 uppercase font-semibold text-md">Class Name</th>
                                                <th class="py-3 px-4 uppercase font-semibold text-md">Subject Name</th>
                                                <th class="py-3 px-4 uppercase font-semibold text-md">Max Marks</th>
                                                <th class="py-3 px-4 uppercase font-semibold text-md"></th>
                                            </tr>
                                        </thead>
                                        <tbody class="text-gray-700 text-center">
                                            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr class="border hover:bg-gray-100">
                                                <td class="py-3 px-4"><?php echo e($loop->iteration); ?></td>
                                                <td class="py-3 px-4"><?php echo e($exam->name); ?></td>
                                                <td class="py-3 px-4"><?php echo e($exam->date); ?></td>
                                                <td class="py-3 px-4"><?php echo e($exam->room->name); ?> - <?php echo e($exam->room->section); ?></td>
                                                <td class="py-3 px-4"><?php echo e($exam->subject->name); ?></td>
                                                <td class="py-3 px-4"><?php echo e($exam->max_marks); ?></td>
                                                <td class="py-3 px-4" onclick="openModal2(<?php echo e($exam->id); ?>)"><i class="fa-solid fa-pen-to-square text-[#1DC7E5]"></i></td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div id="editModel<?php echo e($val->id); ?>" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
                        <div class="bg-white rounded-lg shadow-lg w-full max-w-2xl p-6 relative">

                            <!-- Modal Header -->
                            <div class="flex items-center justify-between border-b pb-3 mb-4">
                                <h5 class="text-lg font-semibold text-gray-700">Modify Exam</h5>
                                <button onclick="closeModal2(<?php echo e($val->id); ?>)" class="text-gray-500 hover:text-red-600 text-2xl">&times;</button>
                            </div>

                            <!-- Modal Body (Your Form) -->
                            <form action="<?php echo e(url('/modify-exam')); ?>" method="POST" class="space-y-6" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div>
                                        <label for="name_<?php echo e($val->id); ?>" class="font-medium">Exam Name</label>
                                        <select name="name" id="name_<?php echo e($val->id); ?>" class="form-select w-full rounded-md mt-1 border-gray-300 focus:border-green-500 focus:ring-green-500">
                                            <option selected disabled>-- Select Exam --</option>
                                            <option value="Midterm" <?php echo e($val->name == 'Midterm' ? 'selected' : ''); ?>>Midterm</option>
                                            <option value="Final" <?php echo e($val->name == 'Final' ? 'selected' : ''); ?>>Final</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="class_id_<?php echo e($val->id); ?>" class="font-medium">Class</label>
                                        <select name="class_id" id="class_id_<?php echo e($val->id); ?>" data-exam-id="<?php echo e($val->id); ?>" class="form-select w-full rounded-md mt-1 border-gray-300 focus:border-green-500 focus:ring-green-500 edit-class-select">
                                            <option disabled selected>-- Select Class --</option>
                                            <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($room->id); ?>" <?php echo e($room->id == $val->class_id ? 'selected' : ''); ?>>
                                                    <?php echo e($room->name); ?> - <?php echo e($room->section); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="subject_id_<?php echo e($val->id); ?>" class="font-medium">Subject</label>
                                        <select name="subject_id" id="subject_id_<?php echo e($val->id); ?>" class="form-select w-full rounded-md mt-1 border-gray-300 focus:border-green-500 focus:ring-green-500">
                                            <option disabled selected>-- Select Subject --</option>
                                            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($sub->class_id == $val->class_id): ?>
                                                    <option value="<?php echo e($sub->id); ?>" <?php echo e($sub->id == $val->subject_id ? 'selected' : ''); ?>>
                                                        <?php echo e($sub->name); ?>

                                                    </option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div>
                                        <label for="date_<?php echo e($val->id); ?>" class="font-medium">Date</label>
                                        <input type="date" name="date" id="date_<?php echo e($val->id); ?>" value="<?php echo e($val->date); ?>" class="form-input w-full rounded-md mt-1 px-2 py-3 border-gray-300 focus:border-green-500 focus:ring-green-500">
                                    </div>
                                </div>

                                <div>
                                    <label for="max_marks_<?php echo e($val->id); ?>" class="font-medium">Max Marks</label>
                                    <input type="number" name="max_marks" id="max_marks_<?php echo e($val->id); ?>" min="0" max="100" value="<?php echo e($val->max_marks); ?>" placeholder="Enter Max Marks" class="form-input w-full rounded-md mt-1 px-2 py-3 border-gray-300 focus:border-green-500 focus:ring-green-500">
                                </div>

                                <!-- Submit Button -->
                                <div class="text-center">
                                    <button type="submit" class="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-6 w-full rounded-md shadow-md transition duration-300" onclick="return confirmSubmit(event)">
                                        Submit
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <!-- [ Main Content ] end -->   
            </div>
        </div>
      <!-- [ Main Content ] end -->
      <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
      <!-- Required Js -->
      <script src="<?php echo e(asset('assets/js/plugins/simplebar.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/plugins/popper.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/icon/custom-icon.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/plugins/feather.min.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/component.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/theme.js')); ?>"></script>
      <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

    <script>
        const subjects = <?php echo json_encode($subjects, 15, 512) ?>;

        document.getElementById('class_id').addEventListener('change', function() {
            const classId = this.value;
            const subjectSelect = document.getElementById('subject_id');
            subjectSelect.innerHTML = '<option disabled selected>-- Select Subject --</option>';

            if (classId) {
                const filteredSubjects = subjects.filter(subject => subject.class_id == classId);
                filteredSubjects.forEach(subject => {
                    const option = document.createElement('option');
                    option.value = subject.id;
                    option.textContent = subject.name;
                    subjectSelect.appendChild(option);
                });
            }
        });

        document.querySelectorAll('.edit-class-select').forEach(selectElement => {
            selectElement.addEventListener('change', function() {
                const classId = this.value;
                const examId = this.dataset.examId;
                const subjectSelect = document.getElementById('subject_id_' + examId);
                subjectSelect.innerHTML = '<option disabled selected>-- Select Subject --</option>';

                if (classId) {
                    const filteredSubjects = subjects.filter(subject => subject.class_id == classId);
                    filteredSubjects.forEach(subject => {
                        const option = document.createElement('option');
                        option.value = subject.id;
                        option.textContent = subject.name;
                        subjectSelect.appendChild(option);
                    });
                }
            });
        });

        // pop up message
        document.addEventListener("DOMContentLoaded", () => {
            const popup = document.getElementById('popup');
            if (popup) {
                // Show popup
                setTimeout(() => {
                    popup.classList.remove('opacity-0', 'translate-y-10');
                }, 100); // small delay for animation

                // Hide popup after 3 seconds
                setTimeout(() => {
                    popup.classList.add('opacity-0', 'translate-y-10');
                }, 3000);
            }
        });

        function confirmSubmit(event) {
            if(!confirm("Are you sure you want to submit?")) {
                event.preventDefault(); // Cancel form submission
                return false;
            }
            return true; // Proceed with form submission
        }

        function openModal() {
            document.getElementById('examModal').classList.remove('hidden');
            document.getElementById('examModal').classList.add('flex');
        }

        function closeModal() {
            document.getElementById('examModal').classList.remove('flex');
            document.getElementById('examModal').classList.add('hidden');
        }

        function openModal2(id) {
            const modal = document.getElementById('editModel' + id);
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        function closeModal2(id) {
            const modal = document.getElementById('editModel' + id);
            modal.classList.remove('flex');
            modal.classList.add('hidden');
        }

    </script>


      <script>
        layout_change('false');
      </script>


      <script>
        layout_theme_sidebar_change('dark');
      </script>


      <script>
        change_box_container('false');
      </script>

      <script>
        layout_caption_change('true');
      </script>

      <script>
        layout_rtl_change('false');
      </script>

      <script>
        preset_change('preset-1');
      </script>

      <script>
        main_layout_change('vertical');
      </script>


  </body>
  <!-- [Body] end -->
</html><?php /**PATH /media/samim-hossen/New Volume1/Basic Software_2025/Software Dev/Web Dev/laravel/SMS/resources/views/exam/exam-list.blade.php ENDPATH**/ ?>