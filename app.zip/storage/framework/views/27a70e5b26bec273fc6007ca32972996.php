<?php if(Session::has('success')): ?>
<div id="popup" 
     class="fixed top-20 right-5 opacity-0 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg transform translate-y-10 transition-all duration-500 ease-in-out">
    <?php echo e(Session::get('success')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('error')): ?>
<div id="popup" 
     class="fixed top-20 right-5 opacity-0 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg transform translate-y-10 transition-all duration-500 ease-in-out">
    <?php echo e(Session::get('error')); ?>

</div>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
<div id="popup" 
     class="fixed top-20 right-5 opacity-0 bg-yellow-500 text-black px-6 py-3 rounded-lg shadow-lg transform translate-y-10 transition-all duration-500 ease-in-out">
    <?php echo e(Session::get('warning')); ?>

</div>
<?php endif; ?>

<?php if($errors->any()): ?>
<div id="popup" 
     class="fixed top-20 right-5 opacity-0 bg-red-500 text-black px-6 py-3 rounded-lg shadow-lg transform translate-y-10 transition-all duration-500 ease-in-out">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?><?php /**PATH /media/samim-hossen/New Volume1/Basic Software_2025/Software Dev/Web Dev/laravel/SMS/resources/views/layouts/message.blade.php ENDPATH**/ ?>