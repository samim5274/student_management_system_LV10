<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>Attendance-(SMS)</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600&display=swap" rel="stylesheet" />
    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/phosphor/duotone/style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/tabler-icons.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/feather.css')); ?>" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/fonts/material.css')); ?>" />
    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" id="main-style-link" />
    
</head>

<body class="bg-gray-50 font-sans">
    
    <!-- Sidebar -->
    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Header -->
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Flash Message -->
    <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- [ Main Content ] start -->
    <div class="pc-container">
        <div class="pc-content">
            
            <!-- Breadcrumb -->
            <div class="page-header mb-6">
                <div class="page-block">
                    <div class="page-header-title">
                        <h5 class="mb-1 font-semibold text-gray-800">Attendance Details</h5>
                    </div>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="/">Home</a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(url('/class-list')); ?>">Attendance</a></li>
                        <li class="breadcrumb-item" aria-current="page">Class List</li>
                    </ul>
                </div>
            </div>

            <!-- search section -->
             <div class="card rounded-md border shadow-md">
                <div class="card-body">
                    <?php
                        $today = date('Y-m-d');
                    ?>

                    <form action="<?php echo e(url('/search-date-wise-attend-student')); ?>" method="GET" class="p-4">
                        <?php echo csrf_field(); ?>
                        <div class="grid md:grid-cols-3 gap-6">

                            
                            <div class="flex flex-col">
                                <label for="start_date" class="text-sm font-medium text-gray-700 mb-1">Start Date</label>
                                <input type="date" 
                                    name="start_date" 
                                    id="start_date"
                                    value="<?php echo e($today); ?>"
                                    max="<?php echo e($today); ?>"
                                    class="border border-gray-300 rounded-lg px-3 py-2 text-md focus:ring-2 focus:ring-theme-bg-1 focus:outline-none">
                            </div>

                            
                            <div class="flex flex-col">
                                <label for="end_date" class="text-sm font-medium text-gray-700 mb-1">End Date</label>
                                <input type="date" 
                                    name="end_date" 
                                    id="end_date"
                                    value="<?php echo e($today); ?>"
                                    max="<?php echo e($today); ?>"
                                    class="border border-gray-300 rounded-lg px-3 py-2 text-md focus:ring-2 focus:ring-theme-bg-1 focus:outline-none">
                            </div>

                            
                            <div class="flex items-end">
                                <button type="submit" 
                                    class="bg-[#3F4D67] text-white px-4 py-2 rounded-lg text-md font-medium shadow hover:bg-[#3F4D67] transition w-full">
                                    Search
                                </button>
                            </div>

                        </div>
                    </form>

                </div>
             </div>

            <!-- Card -->
            <div class="card rounded-lg border shadow-sm">             
                <div class="card-body">  

                    
                    <div class="overflow-x-auto">
                        <table class="min-w-full text-sm text-left text-gray-600 border border-gray-200 rounded-lg">
                            <thead class="bg-gray-100 text-gray-700 uppercase text-xs">
                                <tr>
                                    <th class="px-4 py-3 border text-center" style="width: 50px">#</th>
                                    <th class="px-4 py-3 border">Student Name</th>
                                    <th class="px-4 py-3 border text-center" style="width: 150px">Date</th>
                                    <th class="px-4 py-3 border text-center" style="width: 150px">Class</th>
                                    <th class="px-4 py-3 border text-center" style="width: 100px">Status</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 text-sm text-gray-700">
                                <?php $__currentLoopData = $findData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-50 transition">
                                    <!-- Serial Number -->
                                    <td class="px-4 py-3 border text-center font-medium text-gray-600">
                                        <?php echo e($loop->iteration); ?>

                                    </td>
                                    <!-- Student Name -->
                                    <td class="px-4 py-3 border"> <?php echo e($val->student->first_name); ?> <?php echo e($val->student->last_name); ?></td>
                                    <!-- Student Name -->
                                    <td class="px-4 py-3 border text-center"> <?php echo e($val->class->name); ?> - (<?php echo e($val->class->section); ?>)</td>
                                    <!-- Attendance Date -->
                                    <td class="px-4 py-3 border text-center"> <?php echo e(\Carbon\Carbon::parse($val->attendance_date)->format('d M, Y')); ?></td>
                                    <!-- Attendance Status -->
                                    <td class="px-4 py-3 border text-center">
                                        <?php if($val->status == 'Present'): ?>
                                            <span class="px-3 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">Present</span>
                                        <?php else: ?>
                                            <span class="px-3 py-1 rounded-full text-xs font-semibold bg-red-100 text-red-700">Absent</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- paginatior -->
                    <?php if($findData->hasPages()): ?>
                        <div class="flex flex-wrap items-center justify-between mt-4 w-full">

                            
                            <div class="text-sm md:text-base text-gray-600">
                                Page <?php echo e($findData->currentPage()); ?> of <?php echo e($findData->lastPage()); ?> 
                                (Total Records: <?php echo e($findData->total()); ?>)
                            </div>

                            
                            <div class="flex items-center space-x-2">

                                
                                <?php if($findData->onFirstPage()): ?>
                                    <span class="px-2 py-1 text-sm md:text-base bg-gray-200 text-gray-500 rounded-lg cursor-not-allowed">
                                        &laquo; 
                                    </span>
                                <?php else: ?>
                                    <a href="<?php echo e($findData->appends(request()->query())->previousPageUrl()); ?>" class="px-2 py-1 text-sm md:text-base bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors">
                                        &laquo; 
                                    </a>
                                <?php endif; ?>

                                
                                <?php
                                    $start = max(1, $findData->currentPage() - 2);
                                    $end = min($findData->lastPage(), $findData->currentPage() + 2);
                                ?>

                                <?php for($i = $start; $i <= $end; $i++): ?>
                                    <?php if($i == $findData->currentPage()): ?>
                                        <span class="px-2 py-1 text-sm md:text-base bg-[#3F4D67] text-white rounded-lg"><?php echo e($i); ?></span>
                                    <?php else: ?>
                                        <a href="<?php echo e($findData->appends(request()->query())->url($i)); ?>" class="px-2 py-1 text-sm md:text-base bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors"><?php echo e($i); ?></a>
                                    <?php endif; ?>
                                <?php endfor; ?>

                                
                                <?php if($findData->hasMorePages()): ?>
                                    <a href="<?php echo e($findData->appends(request()->query())->nextPageUrl()); ?>" class="px-2 py-1 text-sm md:text-base bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors">
                                        &raquo;
                                    </a>
                                <?php else: ?>
                                    <span class="px-2 py-1 text-sm md:text-base bg-gray-200 text-gray-500 rounded-lg cursor-not-allowed">
                                        &raquo;
                                    </span>
                                <?php endif; ?>

                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            </div>

            <!-- Card End -->
        </div>
    </div>
    <!-- [ Main Content ] end -->

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
    <!-- Scripts -->
    <script src="<?php echo e(asset('assets/js/plugins/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/icon/custom-icon.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/plugins/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/component.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/theme.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>

    <script>
        // Pop up message (auto-hide)
        document.addEventListener("DOMContentLoaded", () => {
            const popup = document.getElementById('popup');
            if (popup) {
                // Show popup
                setTimeout(() => {
                    popup.classList.remove('opacity-0', 'translate-y-10');
                }, 100); // small delay for animation

                // Hide popup after 3 seconds
                setTimeout(() => {
                    popup.classList.add('opacity-0', 'translate-y-10');
                }, 3000);
            }
        });
    </script>

    <script> layout_change('false'); </script>
    <script> layout_theme_sidebar_change('dark'); </script>
    <script> change_box_container('false'); </script>
    <script> layout_caption_change('true'); </script>
    <script> layout_rtl_change('false'); </script>
    <script> preset_change('preset-1'); </script>
    <script> main_layout_change('vertical'); </script>

</body>
</html>
<?php /**PATH /media/samim-hossen/New Volume1/Basic Software_2025/Software Dev/Web Dev/laravel/SMS/resources/views/attendance/find-student-list.blade.php ENDPATH**/ ?>